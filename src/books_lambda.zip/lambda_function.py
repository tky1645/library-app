import json
import boto3
import uuid
from datetime import datetime
from botocore.exceptions import ClientError

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("Books")

def lambda_handler(event, context):
    operation = event.get("operation")

    if not operation:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "Missing operation"})
        }

    if operation == "create":
        return create_book(event)
    elif operation == "update":
        return update_book(event)
    elif operation == "delete":
        return delete_book(event)
    else:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "Invalid operation"})
        }

def create_book(event):
    try:
        title = event.get("title")
        borrower = event.get("borrower")
        borrowed_date = event.get("borrowed_date")

        if not title or not borrower or not borrowed_date:
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "Missing required field"})
            }

        item = {
            "book_id": str(uuid.uuid4()),
            "title": title,
            "borrower": borrower,
            "borrowed_date": borrowed_date,
            "returned_date": event.get("returned_date", "")
        }
        table.put_item(Item=item)
        return {
            "statusCode": 200,
            "body": json.dumps({"message": "Book created", "book_id": item["book_id"]})
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }

def update_book(event):
    try:
        book_id = event.get("book_id")
        title = event.get("title")
        borrower = event.get("borrower")
        borrowed_date = event.get("borrowed_date")

        if not book_id or (not title and not borrower and not borrowed_date):
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "Missing required field"})
            }

        update_expression = "SET "
        expression_attribute_values = {}

        if title:
            update_expression += "title = :title, "
            expression_attribute_values[":title"] = title

        if borrower:
            update_expression += "borrower = :borrower, "
            expression_attribute_values[":borrower"] = borrower

        if borrowed_date:
            update_expression += "borrowed_date = :borrowed_date, "
            expression_attribute_values[":borrowed_date"] = borrowed_date

        if "returned_date" in event:
            update_expression += "returned_date = :returned_date, "
            expression_attribute_values[":returned_date"] = event["returned_date"]

        if not update_expression.endswith(", "):
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "Missing required field"})
            }

        update_expression = update_expression[:-2]

        table.update_item(
            Key={"book_id": book_id},
            UpdateExpression=update_expression,
            ExpressionAttributeValues=expression_attribute_values
        )

        return {
            "statusCode": 200,
            "body": json.dumps({"message": "Book updated"})
        }
    except ClientError as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }

def delete_book(event):
    try:
        book_id = event.get("book_id")

        if not book_id:
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "Missing required field"})
            }
               
        book_id = event["book_id"]
        table.delete_item(Key={"book_id": book_id})
        return {
            "statusCode": 200,
            "body": json.dumps({"message": "Book deleted"})
        }
    except ClientError as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
    }